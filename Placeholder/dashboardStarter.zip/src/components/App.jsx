import "./App.css";
import Layout from "./layout/Layout";

function App() {
  return (
    <>
      <Layout></Layout>
    </>
  );
}

export default App;
