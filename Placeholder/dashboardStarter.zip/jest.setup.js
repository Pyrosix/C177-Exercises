/**
 * @jest-environment jsdom
 */
import "@testing-library/jest-dom";
import "whatwg-fetch";
