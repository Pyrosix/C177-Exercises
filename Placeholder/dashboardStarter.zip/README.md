# React Dashboard Application

This application corresponds with a Code Along for the Introduction to React Course. Follow the Code-ALong in the Learning Management System.
